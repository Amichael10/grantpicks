import Link from "next/link"
import { ChevronLeft, ChevronRight } from "lucide-react"

interface PaginationProps {
  currentPage: number
  totalPages: number
}

export function Pagination({ currentPage, totalPages }: PaginationProps) {
  const pages = Array.from({ length: totalPages }, (_, i) => i + 1)

  return (
    <div className="flex justify-center items-center gap-2">
      <Link
        href={currentPage > 1 ? `/projects?page=${currentPage - 1}` : "#"}
        className={`flex items-center px-3 py-2 rounded-md ${currentPage === 1 ? "text-gray-400 cursor-not-allowed" : "text-gray-700 hover:bg-gray-100"}`}
        aria-disabled={currentPage === 1}
      >
        <ChevronLeft className="h-4 w-4 mr-1" />
        Previous
      </Link>

      {pages.map((page) => (
        <Link
          key={page}
          href={`/projects?page=${page}`}
          className={`w-10 h-10 flex items-center justify-center rounded-md ${
            currentPage === page ? "bg-gray-900 text-white" : "text-gray-700 hover:bg-gray-100"
          }`}
        >
          {page}
        </Link>
      ))}

      {totalPages > 5 && <span className="px-2">...</span>}

      <Link
        href={currentPage < totalPages ? `/projects?page=${currentPage + 1}` : "#"}
        className={`flex items-center px-3 py-2 rounded-md ${currentPage === totalPages ? "text-gray-400 cursor-not-allowed" : "text-gray-700 hover:bg-gray-100"}`}
        aria-disabled={currentPage === totalPages}
      >
        Next
        <ChevronRight className="h-4 w-4 ml-1" />
      </Link>
    </div>
  )
}

