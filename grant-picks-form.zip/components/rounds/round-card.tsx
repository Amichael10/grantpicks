import { MoreVertical, Users, Clock } from "lucide-react"
import Link from "next/link"

export interface RoundCardProps {
  id: string
  title: string
  logo: string
  isApplicationOpen: boolean
  isParticipating?: boolean
  participantsCount: number
  closesIn: string
}

export function RoundCard({
  id,
  title,
  logo,
  isApplicationOpen,
  isParticipating = false,
  participantsCount,
  closesIn,
}: RoundCardProps) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
      <div className="flex justify-between items-start mb-6">
        <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center overflow-hidden">
          <img src={logo || "/placeholder.svg"} alt={title} className="w-6 h-6" />
        </div>

        <div className="flex items-center gap-2">
          {isApplicationOpen ? (
            <div className="flex items-center gap-1 px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M9 5H7C5.89543 5 5 5.89543 5 7V19C5 20.1046 5.89543 21 7 21H17C18.1046 21 19 20.1046 19 19V7C19 5.89543 18.1046 5 17 5H15"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M12 12H15M12 16H15M9 12H9.01M9 16H9.01"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <rect
                  x="9"
                  y="3"
                  width="6"
                  height="4"
                  rx="1"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              APPLICATION OPEN
            </div>
          ) : (
            <div className="flex items-center gap-1 px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-xs font-medium">
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M9 5H7C5.89543 5 5 5.89543 5 7V19C5 20.1046 5.89543 21 7 21H17C18.1046 21 19 20.1046 19 19V7C19 5.89543 18.1046 5 17 5H15"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M12 12H15M12 16H15M9 12H9.01M9 16H9.01"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <rect
                  x="9"
                  y="3"
                  width="6"
                  height="4"
                  rx="1"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              APPLICATION CLOSED
            </div>
          )}

          <button className="text-gray-400 hover:text-gray-600">
            <MoreVertical className="h-5 w-5" />
          </button>
        </div>
      </div>

      <h3 className="text-xl font-bold text-gray-900 mb-6">{title}</h3>

      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-2 text-gray-600">
          <Users className="h-5 w-5" />
          <span>{participantsCount} Participating</span>
        </div>

        <div className="flex items-center gap-2 text-gray-600">
          <Clock className="h-5 w-5" />
          <span>Closes in {closesIn}</span>
        </div>
      </div>

      {isParticipating ? (
        <div className="w-full py-3 text-center text-gray-500 border border-gray-200 rounded-full">
          You're already a part of this round.
        </div>
      ) : (
        <Link href={`/rounds/${id}/apply`}>
          <button className="w-full py-3 text-center text-gray-700 border border-gray-200 rounded-full hover:bg-gray-50 transition-colors">
            Apply
          </button>
        </Link>
      )}
    </div>
  )
}

