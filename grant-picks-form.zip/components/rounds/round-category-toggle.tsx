"use client"
import { cn } from "@/lib/utils"

type RoundCategory = "active" | "upcoming" | "past"

interface RoundCategoryToggleProps {
  activeCategory: RoundCategory
  onChange: (category: RoundCategory) => void
}

export function RoundCategoryToggle({ activeCategory, onChange }: RoundCategoryToggleProps) {
  return (
    <div className="flex justify-center mb-8">
      <div className="inline-flex bg-gray-100 rounded-lg p-1">
        <button
          onClick={() => onChange("active")}
          className={cn(
            "px-6 py-2 rounded-lg text-sm font-medium transition-colors",
            activeCategory === "active" ? "bg-white text-gray-900 shadow-sm" : "text-gray-600 hover:text-gray-900",
          )}
        >
          Active
        </button>
        <button
          onClick={() => onChange("upcoming")}
          className={cn(
            "px-6 py-2 rounded-lg text-sm font-medium transition-colors",
            activeCategory === "upcoming" ? "bg-white text-gray-900 shadow-sm" : "text-gray-600 hover:text-gray-900",
          )}
        >
          Upcoming
        </button>
        <button
          onClick={() => onChange("past")}
          className={cn(
            "px-6 py-2 rounded-lg text-sm font-medium transition-colors",
            activeCategory === "past" ? "bg-white text-gray-900 shadow-sm" : "text-gray-600 hover:text-gray-900",
          )}
        >
          Past
        </button>
      </div>
    </div>
  )
}

