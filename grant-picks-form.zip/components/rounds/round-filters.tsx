"use client"

import { useState } from "react"
import { Search, ArrowUpDown } from "lucide-react"
import Link from "next/link"

export function RoundFilters() {
  const [searchQuery, setSearchQuery] = useState("")
  const [sortOption, setSortOption] = useState("most-recent")

  const sortOptions = [
    { value: "most-recent", label: "Most Recent" },
    { value: "most-popular", label: "Most Popular" },
    { value: "closing-soon", label: "Closing Soon" },
    { value: "alphabetical", label: "Alphabetical" },
  ]

  return (
    <div className="mb-6">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-grow">
          <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Search rounds..."
            className="pl-10 pr-4 py-2.5 w-full border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="flex gap-4">
          <div className="relative">
            <select
              className="appearance-none pl-4 pr-10 py-2.5 border border-gray-300 rounded-full bg-white focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value)}
            >
              {sortOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
            <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
              <ArrowUpDown className="h-5 w-5 text-gray-400" />
            </div>
          </div>

          <Link href="/rounds/create">
            <button className="px-6 py-2.5 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors">
              Create Round
            </button>
          </Link>
        </div>
      </div>
    </div>
  )
}

