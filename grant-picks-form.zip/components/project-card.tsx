import Link from "next/link"

interface ProjectCardProps {
  project: {
    id: string
    title: string
    description: string
    totalRaised: string
    rounds: number
    logo: string
  }
}

export function ProjectCard({ project }: ProjectCardProps) {
  return (
    <Link href={`/projects/${project.id}`}>
      <div className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
        <div className="flex items-start mb-4">
          <div className="w-12 h-12 rounded-full bg-gradient-to-r from-green-400 to-green-600 flex items-center justify-center overflow-hidden mr-4">
            <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6 text-white">
              <path
                d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M8 14L12 10L16 14"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <h3 className="text-lg font-semibold text-gray-900">{project.title}</h3>
        </div>
        <p className="text-sm text-gray-600 mb-4 line-clamp-3">{project.description}</p>
        <div className="flex justify-between text-sm">
          <div>
            <div className="text-gray-500">Total raised</div>
            <div className="font-medium">{project.totalRaised}</div>
          </div>
          <div className="text-right">
            <div className="text-gray-500">Rounds</div>
            <div className="font-medium">{project.rounds}</div>
          </div>
        </div>
      </div>
    </Link>
  )
}

