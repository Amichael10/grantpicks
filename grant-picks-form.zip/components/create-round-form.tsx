"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { CalendarIcon, ChevronDownIcon, ChevronUpIcon, MinusIcon, PlusIcon } from "lucide-react"
import { format } from "date-fns"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { Switch } from "@/components/ui/switch"
import { Checkbox } from "@/components/ui/checkbox"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { cn } from "@/lib/utils"

// Update the formSchema to include the new fields
const formSchema = z.object({
  title: z.string().min(3, { message: "Title must be at least 3 characters" }),
  description: z.string().min(10, { message: "Description must be at least 10 characters" }),
  votingEndDate: z.date({ required_error: "Please select a voting end date" }),
  votesPerPerson: z.number().min(1, { message: "Minimum of 1 vote required" }),
  contactPlatform: z.string({ required_error: "Please select a platform" }),
  contactUsername: z.string().min(1, { message: "Username is required" }),
  initialDeposit: z.string().optional(),
  expectedAmount: z.string().min(1, { message: "Expected amount is required" }),
  selectedLists: z.array(z.string()).optional(),
  tokenRequirement: z.string().optional(),
  tokenSymbol: z.string().optional(),
  previousParticipation: z.boolean().optional(),
  selectedRounds: z.array(z.string()).optional(),
  cooldownEnabled: z.boolean().default(false),
  cooldownDays: z.number().optional(),
  cooldownDaysUnit: z.string().default("Days"),
  requireComplianceEnabled: z.boolean().default(false),
  complianceDescription: z.string().optional(),
  complianceDays: z.number().optional(),
  complianceDaysUnit: z.string().default("Days"),
  remainingFundsRedistribution: z.string().default("redistribute"),
  customRedistributionDetails: z.string().optional(),
})

// Mock data for lists
const listsData = [
  { id: "list1", name: "Developers Community", projects: 20, member: true, role: null },
  { id: "list2", name: "Climate Action Group", projects: 35, member: false, role: "Owner" },
  { id: "list3", name: "Education Initiatives", projects: 42, member: false, role: "Admin" },
  { id: "list4", name: "Public Goods Funding", projects: 26, member: false, role: null },
  { id: "list5", name: "Women in Tech", projects: 18, member: false, role: null },
  { id: "list6", name: "Healthcare Innovation", projects: 31, member: false, role: null },
  { id: "list7", name: "Open Source Maintainers", projects: 47, member: false, role: null },
  { id: "list8", name: "AI Ethics Research", projects: 15, member: false, role: null },
  { id: "list9", name: "Community Builders", projects: 28, member: false, role: null },
  { id: "list10", name: "DeFi Governance", projects: 22, member: false, role: null },
]

// Mock data for previous rounds
const previousRoundsData = [
  { id: "round1", name: "Climate Action Fund", date: "Jan 2023" },
  { id: "round2", name: "Public Goods Round #4", date: "Mar 2023" },
  { id: "round3", name: "Developer Tooling Grant", date: "May 2023" },
  { id: "round4", name: "Education Initiative", date: "Aug 2023" },
  { id: "round5", name: "Community Building Fund", date: "Oct 2023" },
  { id: "round6", name: "Web3 Infrastructure Grant", date: "Nov 2023" },
  { id: "round7", name: "Ecosystem Growth Fund", date: "Dec 2023" },
  { id: "round8", name: "Privacy & Security Round", date: "Feb 2024" },
  { id: "round9", name: "Decentralized Science", date: "Apr 2024" },
  { id: "round10", name: "Social Impact Projects", date: "Jun 2024" },
]

export function CreateRoundForm() {
  const [votesPerPerson, setVotesPerPerson] = useState(1)
  const [isListsOpen, setIsListsOpen] = useState(false)
  const [listsSearchTerm, setListsSearchTerm] = useState("")
  const [projectsSearchTerm, setProjectsSearchTerm] = useState("")

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      votesPerPerson: 1,
      contactUsername: "",
      initialDeposit: "0.00",
      expectedAmount: "0.00",
      selectedLists: [],
      tokenRequirement: "",
      tokenSymbol: "eth",
      previousParticipation: false,
      selectedRounds: [],
      cooldownEnabled: false,
      cooldownDays: 3,
      cooldownDaysUnit: "Days",
      requireComplianceEnabled: false,
      complianceDescription: "",
      complianceDays: 3,
      complianceDaysUnit: "Days",
      remainingFundsRedistribution: "redistribute",
      customRedistributionDetails: "",
    },
  })

  function onSubmit(values: z.infer<typeof formSchema>) {
    console.log(values)
    // Here you would typically send the data to your API
    alert("Round created successfully!")
  }

  // Filter lists based on search term
  const filteredLists = listsData.filter((list) => list.name.toLowerCase().includes(listsSearchTerm.toLowerCase()))

  // Filter projects based on search term
  const filteredProjects = previousRoundsData.filter((round) =>
    round.name.toLowerCase().includes(projectsSearchTerm.toLowerCase()),
  )

  return (
    <div className="max-w-3xl mx-auto font-titillium">
      <h1 className="text-3xl font-bold text-center mb-2">CREATE NEW ROUND</h1>
      <p className="text-center text-gray-600 mb-8">Set up a new funding round to support projects in your ecosystem</p>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Card className="rounded-xl border-gray-200">
            <CardContent className="p-6">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem className="mb-4">
                    <FormLabel>
                      Round Title <span className="text-red-500">*</span>
                    </FormLabel>
                    <FormControl>
                      <Input
                        className="rounded-lg border-gray-300"
                        placeholder="Enter the title of your funding round"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem className="mb-4">
                    <FormLabel>
                      Round Description <span className="text-red-500">*</span>
                    </FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Describe the purpose and goals of this funding round"
                        className="min-h-[120px] rounded-xl border-gray-300"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="votingEndDate"
                render={({ field }) => (
                  <FormItem className="mb-4">
                    <FormLabel>
                      Voting Duration <span className="text-red-500">*</span>
                    </FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "w-full pl-3 text-left font-normal rounded-lg border-gray-300",
                              !field.value && "text-muted-foreground",
                            )}
                          >
                            {field.value ? format(field.value, "PPP") : "Select voting end date"}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0 rounded-xl border-gray-200" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          disabled={(date) => date < new Date()}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormDescription>Voting will end at 11:59 PM on the selected date</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="votesPerPerson"
                render={({ field }) => (
                  <FormItem className="mb-4">
                    <FormLabel>
                      Votes per person <span className="text-red-500">*</span>
                    </FormLabel>
                    <FormControl>
                      <div className="flex items-center rounded-lg overflow-hidden border border-gray-300">
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          className="rounded-lg rounded-none border-0 border-r border-gray-300"
                          onClick={() => {
                            const newValue = Math.max(1, votesPerPerson - 1)
                            setVotesPerPerson(newValue)
                            field.onChange(newValue)
                          }}
                        >
                          <MinusIcon className="h-4 w-4" />
                        </Button>
                        <Input
                          type="number"
                          className="rounded-lg rounded-none text-center border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
                          value={votesPerPerson}
                          onChange={(e) => {
                            const value = Number.parseInt(e.target.value)
                            if (!isNaN(value) && value >= 1) {
                              setVotesPerPerson(value)
                              field.onChange(value)
                            }
                          }}
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          className="rounded-lg rounded-none border-0 border-l border-gray-300"
                          onClick={() => {
                            const newValue = votesPerPerson + 1
                            setVotesPerPerson(newValue)
                            field.onChange(newValue)
                          }}
                        >
                          <PlusIcon className="h-4 w-4" />
                        </Button>
                      </div>
                    </FormControl>
                    <FormDescription>You must have a minimum of 1 vote.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="mb-4">
                <div className="mb-2">
                  Contact <span className="text-red-500">*</span>
                </div>
                <div className="flex gap-2">
                  <FormField
                    control={form.control}
                    name="contactPlatform"
                    render={({ field }) => (
                      <FormItem className="flex-shrink-0 w-1/3">
                        <FormControl>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <SelectTrigger className="rounded-lg border-gray-300">
                              <SelectValue placeholder="Select platform" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="twitter">Twitter</SelectItem>
                              <SelectItem value="discord">Discord</SelectItem>
                              <SelectItem value="telegram">Telegram</SelectItem>
                              <SelectItem value="email">Email</SelectItem>
                            </SelectContent>
                          </Select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="contactUsername"
                    render={({ field }) => (
                      <FormItem className="flex-grow">
                        <FormControl>
                          <Input className="rounded-lg border-gray-300" placeholder="Your username..." {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="text-sm text-gray-500 mt-1">Leave an address where people can reach out to you.</div>
              </div>
            </CardContent>
          </Card>

          {/* Add Projects Section */}
          <Card className="rounded-xl border-gray-200">
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-lg font-medium">Add Projects</h3>
                <Button className="rounded-lg" variant="ghost" size="icon">
                  <PlusIcon className="h-5 w-5" />
                </Button>
              </div>
              <p className="text-sm text-gray-500">Add a minimum of 10 projects to participate in the round.</p>
            </CardContent>
          </Card>

          {/* Voter Requirements Section */}
          <Card className="rounded-xl border-gray-200">
            <CardContent className="p-6">
              <h3 className="text-lg font-medium mb-1">Voter Requirements</h3>
              <p className="text-sm text-gray-500 mb-4">
                Define who can participate in voting for this funding round. You can restrict voting to specific lists
                of users or add other eligibility criteria.
              </p>

              <Collapsible className="border border-gray-200 rounded-xl mb-4">
                <CollapsibleTrigger className="flex w-full justify-between items-center p-4 hover:bg-gray-50 rounded-xl">
                  <span className="font-medium">Lists</span>
                  {isListsOpen ? <ChevronUpIcon className="h-5 w-5" /> : <ChevronDownIcon className="h-5 w-5" />}
                </CollapsibleTrigger>
                <CollapsibleContent className="px-4 pb-4">
                  <p className="text-sm text-gray-500 mb-3">
                    Select lists of users who will be eligible to vote in this round. Only members of these lists will
                    be able to participate.
                  </p>
                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-3">
                    <p className="text-sm text-blue-800">
                      <span className="font-medium">Note:</span> Users will need to join these lists at{" "}
                      <a
                        href="https://potlock.org/list"
                        className="underline font-medium"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        potlock.org/list
                      </a>{" "}
                      to be eligible to vote in this round.
                    </p>
                  </div>

                  {/* Search input for lists */}
                  <div className="relative mb-3">
                    <Input
                      type="search"
                      className="rounded-lg border-gray-300"
                      placeholder="Search lists..."
                      value={listsSearchTerm}
                      onChange={(e) => setListsSearchTerm(e.target.value)}
                    />
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                      <svg
                        className="w-4 h-4 text-gray-500"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                        ></path>
                      </svg>
                    </div>
                  </div>

                  <FormField
                    control={form.control}
                    name="selectedLists"
                    render={({ field }) => (
                      <FormItem>
                        <div className="max-h-80 overflow-y-auto border border-gray-200 rounded-xl">
                          {filteredLists.length > 0 ? (
                            filteredLists.map((list) => (
                              <div
                                key={list.id}
                                className="flex items-center space-x-3 p-3 border-b last:border-0 hover:bg-gray-50"
                              >
                                <Checkbox
                                  id={list.id}
                                  onCheckedChange={(checked) => {
                                    const currentLists = field.value || []
                                    if (checked) {
                                      field.onChange([...currentLists, list.id])
                                    } else {
                                      field.onChange(currentLists.filter((id) => id !== list.id))
                                    }
                                  }}
                                />
                                <div className="flex items-center space-x-3 flex-1">
                                  <div className="w-12 h-12 rounded-lg bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500"></div>
                                  <div className="flex-1">
                                    <div className="flex justify-between items-center">
                                      <div>
                                        <p className="font-medium">{list.name}</p>
                                        <p className="text-sm text-gray-500">{list.projects} Projects</p>
                                      </div>
                                      {list.role && (
                                        <span className="bg-gray-800 text-white text-xs px-2 py-1 rounded-lg">
                                          {list.role}
                                        </span>
                                      )}
                                    </div>
                                    {list.member && (
                                      <p className="text-sm text-gray-600 mt-1">
                                        <span className="inline-flex items-center">You're a member of this list</span>
                                      </p>
                                    )}
                                  </div>
                                </div>
                              </div>
                            ))
                          ) : (
                            <div className="p-4 text-center text-gray-500">No lists found matching your search.</div>
                          )}
                        </div>
                      </FormItem>
                    )}
                  />
                </CollapsibleContent>
              </Collapsible>

              {/* Token Holding Requirement */}
              <Collapsible className="border border-gray-200 rounded-xl mb-4">
                <CollapsibleTrigger className="flex w-full justify-between items-center p-4 hover:bg-gray-50 rounded-xl">
                  <span className="font-medium">Token Holding</span>
                  <ChevronDownIcon className="h-5 w-5" />
                </CollapsibleTrigger>
                <CollapsibleContent className="px-4 pb-4">
                  <p className="text-sm text-gray-500 mb-3">
                    Require voters to hold a minimum amount of tokens to be eligible to vote.
                  </p>
                  <div className="flex gap-4 items-end">
                    <div className="flex-1">
                      <FormField
                        control={form.control}
                        name="tokenRequirement"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Minimum Token Amount</FormLabel>
                            <FormControl>
                              <Input
                                className="rounded-lg border-gray-300"
                                type="number"
                                placeholder="0"
                                min="0"
                                {...field}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>
                    <div className="flex-1">
                      <FormField
                        control={form.control}
                        name="tokenSymbol"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Token</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="rounded-lg border-gray-300">
                                  <SelectValue placeholder="Select token" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="eth">ETH</SelectItem>
                                <SelectItem value="usdc">USDC</SelectItem>
                                <SelectItem value="dai">DAI</SelectItem>
                                <SelectItem value="custom">Custom...</SelectItem>
                              </SelectContent>
                            </Select>
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                </CollapsibleContent>
              </Collapsible>

              {/* Previous Participation Requirement */}
              <Collapsible className="border border-gray-200 rounded-xl mb-4">
                <CollapsibleTrigger className="flex w-full justify-between items-center p-4 hover:bg-gray-50 rounded-xl">
                  <span className="font-medium">Previous Participation</span>
                  <ChevronDownIcon className="h-5 w-5" />
                </CollapsibleTrigger>
                <CollapsibleContent className="px-4 pb-4">
                  <p className="text-sm text-gray-500 mb-3">
                    Require voters to have participated in previous rounds to be eligible.
                  </p>
                  <FormField
                    control={form.control}
                    name="previousParticipation"
                    render={({ field }) => (
                      <FormItem className="space-y-3 mb-4">
                        <div className="flex items-center space-x-2">
                          <FormControl>
                            <Checkbox
                              id="previous-participation"
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <label
                            htmlFor="previous-participation"
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                          >
                            Require participation in at least one previous round
                          </label>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {form.watch("previousParticipation") && (
                    <div className="border border-gray-200 rounded-xl p-3 bg-gray-50">
                      <p className="text-sm font-medium mb-2">Select eligible previous rounds:</p>

                      {/* Search input for previous rounds */}
                      <div className="relative mb-3">
                        <Input
                          type="search"
                          className="rounded-lg border-gray-300"
                          placeholder="Search rounds..."
                          value={projectsSearchTerm}
                          onChange={(e) => setProjectsSearchTerm(e.target.value)}
                        />
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                          <svg
                            className="w-4 h-4 text-gray-500"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth="2"
                              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                            ></path>
                          </svg>
                        </div>
                      </div>

                      <div className="space-y-2 max-h-60 overflow-y-auto border border-gray-200 rounded-xl bg-white">
                        {filteredProjects.length > 0 ? (
                          <FormField
                            control={form.control}
                            name="selectedRounds"
                            render={({ field }) => (
                              <FormItem className="space-y-0">
                                {filteredProjects.map((round) => (
                                  <div
                                    key={round.id}
                                    className="flex items-center space-x-2 p-3 border-b last:border-0 hover:bg-gray-50"
                                  >
                                    <FormControl>
                                      <Checkbox
                                        id={`round-${round.id}`}
                                        checked={field.value?.includes(round.id)}
                                        onCheckedChange={(checked) => {
                                          const currentRounds = field.value || []
                                          if (checked) {
                                            field.onChange([...currentRounds, round.id])
                                          } else {
                                            field.onChange(currentRounds.filter((id) => id !== round.id))
                                          }
                                        }}
                                      />
                                    </FormControl>
                                    <div>
                                      <label htmlFor={`round-${round.id}`} className="text-sm font-medium">
                                        {round.name}
                                      </label>
                                      <p className="text-xs text-gray-500">{round.date}</p>
                                    </div>
                                  </div>
                                ))}
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        ) : (
                          <div className="p-4 text-center text-gray-500">No rounds found matching your search.</div>
                        )}
                      </div>
                    </div>
                  )}
                </CollapsibleContent>
              </Collapsible>
            </CardContent>
          </Card>

          {/* Cooldown Section */}
          <Card className="rounded-xl border-gray-200">
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium">Cooldown</h3>
                <FormField
                  control={form.control}
                  name="cooldownEnabled"
                  render={({ field }) => (
                    <FormItem className="flex items-center space-x-2 space-y-0">
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {form.watch("cooldownEnabled") && (
                <div className="mt-4">
                  <div className="flex items-center gap-2 mb-1">
                    <span>Set Deadline</span>
                    <span className="text-red-500">*</span>
                  </div>
                  <div className="flex gap-2">
                    <FormField
                      control={form.control}
                      name="cooldownDays"
                      render={({ field }) => (
                        <FormItem className="flex-1">
                          <FormControl>
                            <Input
                              className="rounded-lg border-gray-300"
                              type="number"
                              min="1"
                              placeholder="3"
                              {...field}
                              onChange={(e) => field.onChange(Number(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="cooldownDaysUnit"
                      render={({ field }) => (
                        <FormItem className="w-1/3">
                          <FormControl>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <SelectTrigger className="rounded-lg border-gray-300">
                                <SelectValue placeholder="Days" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Days">Days</SelectItem>
                                <SelectItem value="Weeks">Weeks</SelectItem>
                                <SelectItem value="Months">Months</SelectItem>
                              </SelectContent>
                            </Select>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Require Compliance Section */}
          <Card className="rounded-xl border-gray-200">
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h3 className="text-lg font-medium">Require Compliance</h3>
                  <p className="text-sm text-gray-500">
                    Require projects to submit compliance documentation after the round
                  </p>
                </div>
                <div>
                  <FormField
                    control={form.control}
                    name="requireComplianceEnabled"
                    render={({ field }) => (
                      <FormItem className="flex items-center space-x-2 space-y-0">
                        <FormControl>
                          <Switch checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              {form.watch("requireComplianceEnabled") && (
                <div className="space-y-4 mt-4">
                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-3">
                    <p className="text-sm text-blue-800">
                      <span className="font-medium">What is compliance?</span> Enabling this feature requires funded
                      projects to submit documentation (like receipts, progress reports, etc.) proving they've used
                      funds as promised. Projects that fail to comply by the deadline may have remaining funds
                      redistributed.
                    </p>
                  </div>

                  <FormField
                    control={form.control}
                    name="complianceDescription"
                    render={({ field }) => (
                      <FormItem>
                        <div className="flex items-center gap-2 mb-1">
                          <FormLabel className="mb-0">Compliance Requirements</FormLabel>
                          <span className="text-red-500">*</span>
                        </div>
                        <FormControl>
                          <Textarea
                            placeholder="Describe what documentation projects need to submit (e.g., receipts, progress reports, code commits) and any specific requirements for compliance."
                            className="min-h-[80px] rounded-xl border-gray-300"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          Be specific about what projects need to submit to be considered compliant.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="complianceDays"
                    render={({ field }) => (
                      <FormItem>
                        <div className="flex items-center gap-2 mb-1">
                          <FormLabel className="mb-0">Compliance Deadline</FormLabel>
                          <span className="text-red-500">*</span>
                        </div>
                        <FormDescription className="mt-0 mb-2">
                          Projects must submit compliance documentation within this timeframe after receiving funds.
                        </FormDescription>
                        <div className="flex gap-2">
                          <div className="flex-1">
                            <FormControl>
                              <Input
                                className="rounded-lg border-gray-300"
                                type="number"
                                min="1"
                                placeholder="3"
                                {...field}
                                onChange={(e) => field.onChange(Number(e.target.value))}
                              />
                            </FormControl>
                          </div>

                          <div className="w-1/3">
                            <FormField
                              control={form.control}
                              name="complianceDaysUnit"
                              render={({ field }) => (
                                <FormItem>
                                  <FormControl>
                                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                                      <SelectTrigger className="rounded-lg border-gray-300">
                                        <SelectValue placeholder="Days" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="Days">Days</SelectItem>
                                        <SelectItem value="Weeks">Weeks</SelectItem>
                                        <SelectItem value="Months">Months</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="remainingFundsRedistribution"
                    render={({ field }) => (
                      <FormItem>
                        <div className="flex items-center gap-2 mb-1">
                          <FormLabel className="mb-0">Non-Compliance Action</FormLabel>
                          <span className="text-red-500">*</span>
                        </div>
                        <FormDescription className="mt-0 mb-2">
                          Specify what happens to funds if projects fail to meet compliance requirements.
                        </FormDescription>
                        <FormControl>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <SelectTrigger className="rounded-lg border-gray-300">
                              <SelectValue placeholder="Select action for non-compliant projects" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="redistribute">Redistribute to compliant projects</SelectItem>
                              <SelectItem value="return">Return to funders</SelectItem>
                              <SelectItem value="burn">Burn tokens</SelectItem>
                              <SelectItem value="custom">Custom action (specify below)</SelectItem>
                            </SelectContent>
                          </Select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {form.watch("remainingFundsRedistribution") === "custom" && (
                    <FormField
                      control={form.control}
                      name="customRedistributionDetails"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Custom Action Details</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Describe the custom action for non-compliant projects' funds"
                              className="min-h-[80px] rounded-xl border-gray-300"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="rounded-xl border-gray-200">
            <CardContent className="p-6">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="initialDeposit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Initial Deposit</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <span className="text-gray-500">$</span>
                          </div>
                          <Input
                            className="rounded-lg border-gray-300 pl-8"
                            type="number"
                            step="0.01"
                            min="0"
                            placeholder="Enter amount..."
                            {...field}
                          />
                          <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                            <span className="text-gray-500">USD</span>
                          </div>
                        </div>
                      </FormControl>
                      <FormDescription>
                        The amount you're committing to contribute immediately when creating this round.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="expectedAmount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        Expected Amount <span className="text-red-500">*</span>
                      </FormLabel>
                      <FormControl>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <span className="text-gray-500">$</span>
                          </div>
                          <Input
                            className="rounded-lg border-gray-300 pl-8"
                            type="number"
                            step="0.01"
                            min="0"
                            placeholder="Enter amount..."
                            {...field}
                          />
                          <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                            <span className="text-gray-500">USD</span>
                          </div>
                        </div>
                      </FormControl>
                      <FormDescription>
                        The total funding target you aim to reach for this round from all contributors.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-center">
            <Button type="submit" className="rounded-lg w-full py-6 text-lg bg-gray-900 hover:bg-gray-800 rounded-lg">
              Create Round
            </Button>
          </div>
        </form>
      </Form>
    </div>
  )
}

