"use client"

import { useState, useEffect } from "react"
import { ProjectSearch } from "./project-search"
import { ProjectFilters } from "./project-filters"
import { ProjectGrid } from "./project-grid"
import { ProjectList } from "./project-list"
import { ViewToggle } from "./view-toggle"
import { useDebounce } from "@/hooks/use-debounce"
import { getProjects } from "@/lib/projects"
import type { Project, ProjectTag } from "@/types/project"

export function ProjectDirectory() {
  const [view, setView] = useState<"grid" | "list">("grid")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedTags, setSelectedTags] = useState<ProjectTag[]>([])
  const [sortBy, setSortBy] = useState<"recent" | "name" | "popular">("recent")
  const [projects, setProjects] = useState<Project[]>([])
  const [filteredProjects, setFilteredProjects] = useState<Project[]>([])
  const [isLoading, setIsLoading] = useState(true)

  const debouncedSearchQuery = useDebounce(searchQuery, 300)

  // Fetch projects
  useEffect(() => {
    const fetchProjects = async () => {
      setIsLoading(true)
      try {
        const data = await getProjects()
        setProjects(data)
        setFilteredProjects(data)
      } catch (error) {
        console.error("Failed to fetch projects:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchProjects()
  }, [])

  // Filter and sort projects
  useEffect(() => {
    let result = [...projects]

    // Apply search filter
    if (debouncedSearchQuery) {
      result = result.filter(
        (project) =>
          project.name.toLowerCase().includes(debouncedSearchQuery.toLowerCase()) ||
          project.description.toLowerCase().includes(debouncedSearchQuery.toLowerCase()),
      )
    }

    // Apply tag filters
    if (selectedTags.length > 0) {
      result = result.filter((project) => selectedTags.every((tag) => project.tags.includes(tag)))
    }

    // Apply sorting
    switch (sortBy) {
      case "recent":
        result.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
        break
      case "name":
        result.sort((a, b) => a.name.localeCompare(b.name))
        break
      case "popular":
        result.sort((a, b) => b.stars - a.stars)
        break
    }

    setFilteredProjects(result)
  }, [projects, debouncedSearchQuery, selectedTags, sortBy])

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Project Directory</h1>
        <p className="text-lg text-gray-600 max-w-3xl">
          Discover and collaborate on blockchain projects. Find the perfect project to contribute to or showcase your
          own work.
        </p>
      </div>

      <div className="flex flex-col lg:flex-row gap-8 mb-8">
        <div className="w-full lg:w-2/3">
          <ProjectSearch searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
        </div>
        <div className="w-full lg:w-1/3 flex justify-end items-center gap-4">
          <ViewToggle view={view} setView={setView} />
          <button className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors flex items-center gap-2">
            <span className="text-lg">+</span>
            <span>Create Project</span>
          </button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        <div className="w-full lg:w-1/4">
          <ProjectFilters
            selectedTags={selectedTags}
            setSelectedTags={setSelectedTags}
            sortBy={sortBy}
            setSortBy={setSortBy}
          />
        </div>
        <div className="w-full lg:w-3/4">
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
            </div>
          ) : (
            <>
              {filteredProjects.length === 0 ? (
                <div className="bg-white rounded-lg p-8 text-center">
                  <h3 className="text-xl font-semibold mb-2">No projects found</h3>
                  <p className="text-gray-600 mb-4">
                    Try adjusting your search or filters to find what you're looking for.
                  </p>
                  <button
                    onClick={() => {
                      setSearchQuery("")
                      setSelectedTags([])
                    }}
                    className="text-primary hover:underline"
                  >
                    Clear all filters
                  </button>
                </div>
              ) : view === "grid" ? (
                <ProjectGrid projects={filteredProjects} />
              ) : (
                <ProjectList projects={filteredProjects} />
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}

