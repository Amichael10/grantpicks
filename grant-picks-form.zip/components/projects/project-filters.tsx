"use client"

import { useState } from "react"
import type { ProjectTag } from "@/types/project"
import { Filter, ChevronDown, ChevronUp, Check } from "lucide-react"

interface ProjectFiltersProps {
  selectedTags: ProjectTag[]
  setSelectedTags: (tags: ProjectTag[]) => void
  sortBy: "recent" | "name" | "popular"
  setSortBy: (sortBy: "recent" | "name" | "popular") => void
}

export function ProjectFilters({ selectedTags, setSelectedTags, sortBy, setSortBy }: ProjectFiltersProps) {
  const [isTagsOpen, setIsTagsOpen] = useState(true)
  const [isContributorsOpen, setIsContributorsOpen] = useState(true)
  const [isStatusOpen, setIsStatusOpen] = useState(true)

  // Available tags
  const availableTags: ProjectTag[] = [
    "DeFi",
    "NFT",
    "Gaming",
    "Infrastructure",
    "Social",
    "DAO",
    "Privacy",
    "Scaling",
    "Identity",
    "Wallet",
    "Exchange",
    "Analytics",
  ]

  // Toggle tag selection
  const toggleTag = (tag: ProjectTag) => {
    if (selectedTags.includes(tag)) {
      setSelectedTags(selectedTags.filter((t) => t !== tag))
    } else {
      setSelectedTags([...selectedTags, tag])
    }
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Filter className="h-5 w-5 text-gray-500" />
          <h3 className="font-semibold text-lg">Filters</h3>
        </div>
        <button
          onClick={() => {
            setSelectedTags([])
            setSortBy("recent")
          }}
          className="text-sm text-primary hover:underline"
        >
          Clear all
        </button>
      </div>

      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">Sort by</label>
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as "recent" | "name" | "popular")}
          className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
        >
          <option value="recent">Most Recent</option>
          <option value="name">Alphabetical</option>
          <option value="popular">Most Popular</option>
        </select>
      </div>

      <div className="border-t border-gray-200 pt-4 mb-4">
        <button
          className="flex items-center justify-between w-full text-left font-medium mb-2"
          onClick={() => setIsTagsOpen(!isTagsOpen)}
        >
          <span>Tags</span>
          {isTagsOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </button>

        {isTagsOpen && (
          <div className="space-y-2 mt-3">
            {availableTags.map((tag) => (
              <div key={tag} className="flex items-center">
                <button
                  onClick={() => toggleTag(tag)}
                  className={`flex items-center justify-between w-full p-2 rounded-md ${
                    selectedTags.includes(tag) ? "bg-primary/10 text-primary" : "hover:bg-gray-100"
                  }`}
                >
                  <span>{tag}</span>
                  {selectedTags.includes(tag) && <Check className="h-4 w-4" />}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="border-t border-gray-200 pt-4 mb-4">
        <button
          className="flex items-center justify-between w-full text-left font-medium mb-2"
          onClick={() => setIsContributorsOpen(!isContributorsOpen)}
        >
          <span>Contributors</span>
          {isContributorsOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </button>

        {isContributorsOpen && (
          <div className="space-y-2 mt-3">
            <div className="flex items-center">
              <input type="checkbox" id="contributor-1" className="rounded text-primary focus:ring-primary" />
              <label htmlFor="contributor-1" className="ml-2 text-sm">
                Alice (23)
              </label>
            </div>
            <div className="flex items-center">
              <input type="checkbox" id="contributor-2" className="rounded text-primary focus:ring-primary" />
              <label htmlFor="contributor-2" className="ml-2 text-sm">
                Bob (18)
              </label>
            </div>
            <div className="flex items-center">
              <input type="checkbox" id="contributor-3" className="rounded text-primary focus:ring-primary" />
              <label htmlFor="contributor-3" className="ml-2 text-sm">
                Charlie (15)
              </label>
            </div>
            <div className="flex items-center">
              <input type="checkbox" id="contributor-4" className="rounded text-primary focus:ring-primary" />
              <label htmlFor="contributor-4" className="ml-2 text-sm">
                Diana (12)
              </label>
            </div>
            <div className="flex items-center">
              <input type="checkbox" id="contributor-5" className="rounded text-primary focus:ring-primary" />
              <label htmlFor="contributor-5" className="ml-2 text-sm">
                Evan (9)
              </label>
            </div>
          </div>
        )}
      </div>

      <div className="border-t border-gray-200 pt-4">
        <button
          className="flex items-center justify-between w-full text-left font-medium mb-2"
          onClick={() => setIsStatusOpen(!isStatusOpen)}
        >
          <span>Status</span>
          {isStatusOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </button>

        {isStatusOpen && (
          <div className="space-y-2 mt-3">
            <div className="flex items-center">
              <input type="checkbox" id="status-1" className="rounded text-primary focus:ring-primary" />
              <label htmlFor="status-1" className="ml-2 text-sm">
                Active (45)
              </label>
            </div>
            <div className="flex items-center">
              <input type="checkbox" id="status-2" className="rounded text-primary focus:ring-primary" />
              <label htmlFor="status-2" className="ml-2 text-sm">
                Completed (32)
              </label>
            </div>
            <div className="flex items-center">
              <input type="checkbox" id="status-3" className="rounded text-primary focus:ring-primary" />
              <label htmlFor="status-3" className="ml-2 text-sm">
                In Development (28)
              </label>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

