"use client"

import type { Project } from "@/types/project"
import { useState } from "react"
import { cn } from "@/lib/utils"
import { AboutTab } from "./tabs/about-tab"
import { TeamTab } from "./tabs/team-tab"
import { RoundsTab } from "./tabs/rounds-tab"
import { FundingHistoryTab } from "./tabs/funding-history-tab"

interface ProjectTabsProps {
  project: Project
}

export function ProjectTabs({ project }: ProjectTabsProps) {
  const [activeTab, setActiveTab] = useState<"about" | "team" | "rounds" | "funding">("about")

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden font-titillium">
      <div className="border-b border-gray-100">
        <div className="flex">
          <button
            onClick={() => setActiveTab("about")}
            className={cn(
              "px-6 py-4 text-sm font-medium border-b-2 border-transparent",
              activeTab === "about" && "border-primary text-primary",
            )}
          >
            About
          </button>
          <button
            onClick={() => setActiveTab("team")}
            className={cn(
              "px-6 py-4 text-sm font-medium border-b-2 border-transparent",
              activeTab === "team" && "border-primary text-primary",
            )}
          >
            Team
          </button>
          <button
            onClick={() => setActiveTab("rounds")}
            className={cn(
              "px-6 py-4 text-sm font-medium border-b-2 border-transparent flex items-center gap-2",
              activeTab === "rounds" && "border-primary text-primary",
            )}
          >
            <span>Rounds</span>
            <span className="bg-gray-100 text-gray-700 text-xs px-2 py-0.5 rounded-full">12</span>
          </button>
          <button
            onClick={() => setActiveTab("funding")}
            className={cn(
              "px-6 py-4 text-sm font-medium border-b-2 border-transparent",
              activeTab === "funding" && "border-primary text-primary",
            )}
          >
            Funding History
          </button>
        </div>
      </div>

      <div className="p-6">
        {activeTab === "about" && <AboutTab project={project} />}
        {activeTab === "team" && <TeamTab project={project} />}
        {activeTab === "rounds" && <RoundsTab project={project} />}
        {activeTab === "funding" && <FundingHistoryTab project={project} />}
      </div>
    </div>
  )
}

