"use client"

import { Grid, List } from "lucide-react"

interface ViewToggleProps {
  view: "grid" | "list"
  setView: (view: "grid" | "list") => void
}

export function ViewToggle({ view, setView }: ViewToggleProps) {
  return (
    <div className="flex border border-gray-300 rounded-lg overflow-hidden">
      <button
        className={`p-2 ${view === "grid" ? "bg-gray-100 text-gray-900" : "bg-white text-gray-500 hover:bg-gray-50"}`}
        onClick={() => setView("grid")}
        aria-label="Grid view"
      >
        <Grid className="h-5 w-5" />
      </button>
      <button
        className={`p-2 ${view === "list" ? "bg-gray-100 text-gray-900" : "bg-white text-gray-500 hover:bg-gray-50"}`}
        onClick={() => setView("list")}
        aria-label="List view"
      >
        <List className="h-5 w-5" />
      </button>
    </div>
  )
}

