import type { Project } from "@/types/project"

interface ProjectStatsProps {
  project: Project
}

export function ProjectStats({ project }: ProjectStatsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 border-t border-gray-100">
      <div className="p-6 flex items-center gap-4 border-b md:border-b-0 md:border-r border-gray-100">
        <div className="w-10 h-10 rounded-md bg-gray-100 flex items-center justify-center text-gray-500">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM9 17H7V10H9V17ZM13 17H11V7H13V17ZM17 17H15V13H17V17Z"
              fill="currentColor"
            />
          </svg>
        </div>
        <div>
          <div className="text-2xl font-bold">12</div>
          <div className="text-sm text-gray-500 uppercase">Rounds Participated</div>
        </div>
      </div>
      <div className="p-6 flex items-center gap-4 border-b md:border-b-0 md:border-r border-gray-100">
        <div className="w-10 h-10 rounded-md bg-gray-100 flex items-center justify-center text-gray-500">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM12 20C7.59 20 4 16.41 4 12C4 7.59 7.59 4 12 4C16.41 4 20 7.59 20 12C20 16.41 16.41 20 12 20ZM12.31 11.14C10.54 10.69 9.97 10.2 9.97 9.47C9.97 8.63 10.76 8.04 12.07 8.04C13.45 8.04 13.97 8.7 14.01 9.68H15.72C15.67 8.34 14.85 7.11 13.23 6.71V5H10.9V6.69C9.39 7.01 8.18 7.99 8.18 9.5C8.18 11.29 9.67 12.19 11.84 12.71C13.79 13.17 14.18 13.86 14.18 14.58C14.18 15.11 13.79 15.97 12.08 15.97C10.48 15.97 9.85 15.25 9.76 14.33H8.04C8.14 16.03 9.4 16.99 10.9 17.3V19H13.24V17.33C14.76 17.04 15.98 16.17 15.98 14.56C15.98 12.36 14.07 11.6 12.31 11.14Z"
              fill="currentColor"
            />
          </svg>
        </div>
        <div>
          <div className="text-2xl font-bold">300 NEAR</div>
          <div className="text-sm text-gray-500 uppercase">Funding Received</div>
        </div>
      </div>
      <div className="p-6 flex items-center gap-4">
        <div className="w-10 h-10 rounded-md bg-gray-100 flex items-center justify-center text-gray-500">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M18 13H17.32L15.32 15H17.23L19 17H5L6.78 15H8.83L6.83 13H6L3 16V18C3 19.1 3.9 20 5 20H19C20.1 20 21 19.1 21 18V16L18 13ZM17 7.95L12.05 12.9L8.51 9.36L13.46 4.41L17 7.95ZM12.76 2.29L6.39 8.66C6 9.05 6 9.68 6.39 10.07L11.34 15.02C11.73 15.41 12.36 15.41 12.75 15.02L19.11 8.66C19.5 8.27 19.5 7.64 19.11 7.25L14.16 2.3C13.78 1.9 13.15 1.9 12.76 2.29Z"
              fill="currentColor"
            />
          </svg>
        </div>
        <div>
          <div className="text-2xl font-bold">300</div>
          <div className="text-sm text-gray-500 uppercase">Total Votes</div>
        </div>
      </div>
    </div>
  )
}

