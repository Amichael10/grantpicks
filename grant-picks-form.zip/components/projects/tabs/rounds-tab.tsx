import type { Project } from "@/types/project"
import { Calendar, Users, Award } from "lucide-react"
import Link from "next/link"

interface RoundsTabProps {
  project: Project
}

export function RoundsTab({ project }: RoundsTabProps) {
  // Mock data for active rounds
  const activeRounds = [
    {
      id: "round-1",
      name: "NEAR Ecosystem Growth Fund - Q1 2024",
      description: "Supporting projects building on NEAR Protocol that contribute to ecosystem growth.",
      startDate: "Jan 15, 2024",
      endDate: "Mar 15, 2024",
      amountRequested: "50,000 NEAR",
      votes: 187,
      status: "Active",
      currentRank: 3,
      totalProjects: 42,
    },
    {
      id: "round-2",
      name: "Global Financial Inclusion Round",
      description: "Funding projects that expand access to financial services in underserved regions.",
      startDate: "Feb 1, 2024",
      endDate: "Mar 31, 2024",
      amountRequested: "75,000 NEAR",
      votes: 203,
      status: "Active",
      currentRank: 1,
      totalProjects: 28,
    },
  ]

  // Mock data for past rounds
  const pastRounds = [
    {
      id: "round-3",
      name: "NEAR Community Fund - Q4 2023",
      description: "Supporting community-driven projects on NEAR.",
      startDate: "Oct 1, 2023",
      endDate: "Dec 15, 2023",
      amountRequested: "30,000 NEAR",
      amountReceived: "27,500 NEAR",
      votes: 156,
      status: "Completed",
      finalRank: 5,
      totalProjects: 37,
    },
    {
      id: "round-4",
      name: "DeFi Innovation Grant",
      description: "Funding innovative DeFi applications.",
      startDate: "Aug 15, 2023",
      endDate: "Sep 30, 2023",
      amountRequested: "45,000 NEAR",
      amountReceived: "45,000 NEAR",
      votes: 278,
      status: "Completed",
      finalRank: 2,
      totalProjects: 45,
    },
    {
      id: "round-5",
      name: "Public Goods Funding Round #3",
      description: "Supporting projects that provide public goods to the blockchain ecosystem.",
      startDate: "May 1, 2023",
      endDate: "Jun 30, 2023",
      amountRequested: "25,000 NEAR",
      amountReceived: "22,000 NEAR",
      votes: 132,
      status: "Completed",
      finalRank: 8,
      totalProjects: 52,
    },
    {
      id: "round-6",
      name: "NEAR Grants Program - Q2 2023",
      description: "General funding for projects building on NEAR.",
      startDate: "Apr 1, 2023",
      endDate: "Jun 15, 2023",
      amountRequested: "35,000 NEAR",
      amountReceived: "35,000 NEAR",
      votes: 189,
      status: "Completed",
      finalRank: 4,
      totalProjects: 63,
    },
  ]

  // Mock data for upcoming rounds
  const upcomingRounds = [
    {
      id: "round-7",
      name: "NEAR Ecosystem Fund - Q2 2024",
      description: "Supporting projects building on NEAR Protocol.",
      startDate: "Apr 1, 2024",
      endDate: "Jun 30, 2024",
      amountRequested: "60,000 NEAR",
      status: "Upcoming",
    },
  ]

  return (
    <div className="space-y-10">
      <section>
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-gray-900">Active Rounds</h3>
          <Link href="/rounds/active" className="text-primary text-sm font-medium hover:underline">
            View All Active Rounds
          </Link>
        </div>

        <div className="space-y-4">
          {activeRounds.map((round) => (
            <div key={round.id} className="bg-white border border-gray-100 rounded-lg p-6 shadow-sm">
              <div className="flex justify-between items-start mb-4">
                <h4 className="font-bold text-gray-900">{round.name}</h4>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                  {round.status}
                </span>
              </div>

              <p className="text-gray-600 mb-4">{round.description}</p>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-gray-500" />
                  <div className="text-sm">
                    <div className="text-gray-500">Start Date</div>
                    <div className="font-medium">{round.startDate}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-gray-500" />
                  <div className="text-sm">
                    <div className="text-gray-500">End Date</div>
                    <div className="font-medium">{round.endDate}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-gray-500" />
                  <div className="text-sm">
                    <div className="text-gray-500">Votes</div>
                    <div className="font-medium">{round.votes}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Award className="h-4 w-4 text-gray-500" />
                  <div className="text-sm">
                    <div className="text-gray-500">Current Rank</div>
                    <div className="font-medium">
                      {round.currentRank} of {round.totalProjects}
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-between items-center pt-4 border-t border-gray-100">
                <div className="text-sm">
                  <span className="text-gray-500">Requested:</span>
                  <span className="font-medium ml-1">{round.amountRequested}</span>
                </div>
                <Link href={`/rounds/${round.id}`} className="text-primary text-sm font-medium hover:underline">
                  View Round Details
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-gray-900">Upcoming Rounds</h3>
        </div>

        <div className="space-y-4">
          {upcomingRounds.map((round) => (
            <div key={round.id} className="bg-white border border-gray-100 rounded-lg p-6 shadow-sm">
              <div className="flex justify-between items-start mb-4">
                <h4 className="font-bold text-gray-900">{round.name}</h4>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                  {round.status}
                </span>
              </div>

              <p className="text-gray-600 mb-4">{round.description}</p>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-gray-500" />
                  <div className="text-sm">
                    <div className="text-gray-500">Start Date</div>
                    <div className="font-medium">{round.startDate}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-gray-500" />
                  <div className="text-sm">
                    <div className="text-gray-500">End Date</div>
                    <div className="font-medium">{round.endDate}</div>
                  </div>
                </div>
              </div>

              <div className="flex justify-between items-center pt-4 border-t border-gray-100">
                <div className="text-sm">
                  <span className="text-gray-500">Requested:</span>
                  <span className="font-medium ml-1">{round.amountRequested}</span>
                </div>
                <Link href={`/rounds/${round.id}`} className="text-primary text-sm font-medium hover:underline">
                  View Round Details
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-gray-900">Past Rounds</h3>
          <Link href="/rounds/past" className="text-primary text-sm font-medium hover:underline">
            View All Past Rounds
          </Link>
        </div>

        <div className="bg-white border border-gray-100 rounded-lg shadow-sm overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Round Name
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Date
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Amount
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Votes
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Rank
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {pastRounds.map((round) => (
                <tr key={round.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="font-medium text-gray-900">{round.name}</div>
                    <div className="text-xs text-gray-500 mt-1">{round.description.substring(0, 50)}...</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {round.startDate} - {round.endDate}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <div className="text-xs text-gray-500">Requested</div>
                    <div className="font-medium">{round.amountRequested}</div>
                    <div className="text-xs text-gray-500 mt-1">Received</div>
                    <div className="font-medium">{round.amountReceived}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{round.votes}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {round.finalRank} of {round.totalProjects}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <Link href={`/rounds/${round.id}`} className="text-primary hover:underline">
                      Details
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  )
}

