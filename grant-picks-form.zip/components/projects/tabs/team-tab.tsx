import type { Project } from "@/types/project"

interface TeamTabProps {
  project: Project
}

export function TeamTab({ project }: TeamTabProps) {
  // Mock team data - simplified to just name and .near ID
  const teamMembers = [
    {
      id: 1,
      name: "Kritik Namir",
      nearId: "kritik.near",
      avatar: "/placeholder.svg?height=120&width=120",
    },
    {
      id: 2,
      name: "Sophia Chen",
      nearId: "sophia.near",
      avatar: "/placeholder.svg?height=120&width=120",
    },
    {
      id: 3,
      name: "Marcus Johnson",
      nearId: "marcus.near",
      avatar: "/placeholder.svg?height=120&width=120",
    },
    {
      id: 4,
      name: "Aisha Okoye",
      nearId: "aisha.near",
      avatar: "/placeholder.svg?height=120&width=120",
    },
  ]

  return (
    <div className="space-y-10">
      <section>
        <h3 className="text-xl font-bold text-gray-900 mb-6">Core Team</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {teamMembers.map((member) => (
            <div key={member.id} className="bg-white border border-gray-100 rounded-lg p-6 shadow-sm">
              <div className="flex items-center gap-4">
                <img
                  src={member.avatar || "/placeholder.svg"}
                  alt={member.name}
                  className="w-16 h-16 rounded-full object-cover"
                />
                <div>
                  <h4 className="font-bold text-gray-900">{member.name}</h4>
                  <p className="text-primary text-sm font-medium">{member.nearId}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}

