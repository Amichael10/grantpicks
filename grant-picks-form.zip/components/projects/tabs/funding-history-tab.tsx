import type { Project } from "@/types/project"
import { DollarSign, PieChart, Calendar } from "lucide-react"

interface FundingHistoryTabProps {
  project: Project
}

export function FundingHistoryTab({ project }: FundingHistoryTabProps) {
  // Mock funding data
  const totalFunding = "129,500 NEAR"

  const fundingSources = [
    { source: "Grant Rounds", amount: "95,000 NEAR", percentage: 73 },
    { source: "Individual Donations", amount: "22,500 NEAR", percentage: 17 },
    { source: "DAO Allocations", amount: "12,000 NEAR", percentage: 10 },
  ]

  const fundingTimeline = [
    {
      date: "Mar 2024",
      source: "Global Financial Inclusion Round",
      amount: "25,000 NEAR",
      status: "Pending",
    },
    {
      date: "Dec 2023",
      source: "NEAR Community Fund - Q4 2023",
      amount: "27,500 NEAR",
      status: "Received",
    },
    {
      date: "Sep 2023",
      source: "DeFi Innovation Grant",
      amount: "45,000 NEAR",
      status: "Received",
    },
    {
      date: "Jun 2023",
      source: "Public Goods Funding Round #3",
      amount: "22,000 NEAR",
      status: "Received",
    },
    {
      date: "Jun 2023",
      source: "NEAR Grants Program - Q2 2023",
      amount: "35,000 NEAR",
      status: "Received",
    },
  ]

  return (
    <div className="space-y-10">
      <section>
        <div className="flex items-center gap-4 mb-6">
          <DollarSign className="h-6 w-6 text-primary" />
          <h3 className="text-xl font-bold text-gray-900">Total Funding Received</h3>
        </div>

        <div className="bg-white border border-gray-100 rounded-lg p-6 shadow-sm">
          <div className="text-4xl font-bold text-gray-900 mb-4">{totalFunding}</div>
          <p className="text-gray-600">Total funding received across all sources since project inception.</p>
        </div>
      </section>

      <section>
        <div className="flex items-center gap-4 mb-6">
          <PieChart className="h-6 w-6 text-primary" />
          <h3 className="text-xl font-bold text-gray-900">Funding Sources</h3>
        </div>

        <div className="bg-white border border-gray-100 rounded-lg p-6 shadow-sm">
          <div className="space-y-4">
            {fundingSources.map((source, index) => (
              <div key={index}>
                <div className="flex justify-between items-center mb-1">
                  <span className="font-medium text-gray-900">{source.source}</span>
                  <span className="text-gray-600">
                    {source.amount} ({source.percentage}%)
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div className="bg-primary h-2.5 rounded-full" style={{ width: `${source.percentage}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section>
        <div className="flex items-center gap-4 mb-6">
          <Calendar className="h-6 w-6 text-primary" />
          <h3 className="text-xl font-bold text-gray-900">Funding Timeline</h3>
        </div>

        <div className="bg-white border border-gray-100 rounded-lg shadow-sm overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Date
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Source
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Amount
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {fundingTimeline.map((item, index) => (
                <tr key={index}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{item.date}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{item.source}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{item.amount}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        item.status === "Received" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"
                      }`}
                    >
                      {item.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  )
}

