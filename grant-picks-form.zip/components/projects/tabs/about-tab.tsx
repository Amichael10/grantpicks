import type { Project } from "@/types/project"

interface AboutTabProps {
  project: Project
}

export function AboutTab({ project }: AboutTabProps) {
  return (
    <div className="space-y-8">
      <section>
        <h3 className="text-xl font-bold text-gray-900 mb-4">Project Description</h3>
        <p className="text-gray-700 leading-relaxed">
          World Liberty Financial is a decentralized platform that aims to provide financial services to underserved
          communities around the world. By leveraging blockchain technology, we're creating a more inclusive financial
          ecosystem that empowers individuals regardless of their location or economic status.
        </p>
      </section>

      <section>
        <h3 className="text-xl font-bold text-gray-900 mb-4">Problem Statement</h3>
        <p className="text-gray-700 leading-relaxed">
          Over 1.7 billion adults worldwide remain unbanked, lacking access to basic financial services. Traditional
          banking systems often exclude individuals due to geographical limitations, high fees, or minimum balance
          requirements. This financial exclusion perpetuates poverty cycles and limits economic growth in developing
          regions.
        </p>
      </section>

      <section>
        <h3 className="text-xl font-bold text-gray-900 mb-4">Our Solution</h3>
        <p className="text-gray-700 leading-relaxed">
          World Liberty Financial provides a suite of blockchain-based financial tools that require only a smartphone
          and internet connection. Our platform offers:
        </p>
        <ul className="list-disc list-inside mt-2 space-y-2 text-gray-700">
          <li>Peer-to-peer lending and borrowing with flexible terms</li>
          <li>Microloans for small business development</li>
          <li>Decentralized savings accounts with competitive yields</li>
          <li>Cross-border payments with minimal fees</li>
          <li>Financial education resources in multiple languages</li>
        </ul>
      </section>

      <section>
        <h3 className="text-xl font-bold text-gray-900 mb-4">Public Goods Justification</h3>
        <p className="text-gray-700 leading-relaxed">
          World Liberty Financial qualifies as a public good because it provides essential financial infrastructure
          that:
        </p>
        <ul className="list-disc list-inside mt-2 space-y-2 text-gray-700">
          <li>Is accessible to anyone regardless of socioeconomic status</li>
          <li>Promotes financial inclusion in underserved regions</li>
          <li>Reduces dependency on centralized financial institutions</li>
          <li>Creates economic opportunities in developing communities</li>
          <li>Provides open-source financial tools that others can build upon</li>
        </ul>
      </section>
    </div>
  )
}

