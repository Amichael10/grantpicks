import Link from "next/link"
import { ChevronLeft, ChevronRight } from "lucide-react"

interface PaginationProps {
  currentPage: number
  totalPages: number
}

export function Pagination({ currentPage, totalPages }: PaginationProps) {
  // Generate page numbers to display
  const getPageNumbers = () => {
    const pages = []

    // Always show first page
    pages.push(1)

    // Calculate range around current page
    const rangeStart = Math.max(2, currentPage - 1)
    const rangeEnd = Math.min(totalPages - 1, currentPage + 1)

    // Add ellipsis if needed before range
    if (rangeStart > 2) {
      pages.push("ellipsis-start")
    }

    // Add pages in range
    for (let i = rangeStart; i <= rangeEnd; i++) {
      pages.push(i)
    }

    // Add ellipsis if needed after range
    if (rangeEnd < totalPages - 1) {
      pages.push("ellipsis-end")
    }

    // Always show last page if there is more than one page
    if (totalPages > 1) {
      pages.push(totalPages)
    }

    return pages
  }

  const pageNumbers = getPageNumbers()

  return (
    <div className="flex justify-center items-center">
      <nav className="flex items-center gap-1">
        <Link
          href={currentPage > 1 ? `/projects?page=${currentPage - 1}` : "#"}
          className={`flex items-center px-3 py-2 rounded-md ${
            currentPage === 1 ? "text-gray-300 cursor-not-allowed" : "text-gray-700 hover:bg-gray-100"
          }`}
          aria-disabled={currentPage === 1}
        >
          <ChevronLeft className="h-4 w-4 mr-1" />
          <span className="hidden sm:inline">Previous</span>
        </Link>

        <div className="flex items-center">
          {pageNumbers.map((page, index) => {
            if (page === "ellipsis-start" || page === "ellipsis-end") {
              return (
                <span key={page} className="px-2 text-gray-400">
                  ...
                </span>
              )
            }

            return (
              <Link
                key={index}
                href={`/projects?page=${page}`}
                className={`w-9 h-9 flex items-center justify-center rounded-md mx-1 ${
                  currentPage === page ? "bg-green-600 text-white font-medium" : "text-gray-700 hover:bg-gray-100"
                }`}
              >
                {page}
              </Link>
            )
          })}
        </div>

        <Link
          href={currentPage < totalPages ? `/projects?page=${currentPage + 1}` : "#"}
          className={`flex items-center px-3 py-2 rounded-md ${
            currentPage === totalPages ? "text-gray-300 cursor-not-allowed" : "text-gray-700 hover:bg-gray-100"
          }`}
          aria-disabled={currentPage === totalPages}
        >
          <span className="hidden sm:inline">Next</span>
          <ChevronRight className="h-4 w-4 ml-1" />
        </Link>
      </nav>
    </div>
  )
}

