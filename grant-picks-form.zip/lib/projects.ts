import type { Project, ProjectTag } from "@/types/project"

// Create a fixed set of project IDs for consistency
const PROJECT_IDS = Array(24)
  .fill(null)
  .map((_, i) => `project-${i + 1}`)

// Mock data for projects with fixed IDs
const mockProjects: Project[] = PROJECT_IDS.map((id, index) => {
  const tags: ProjectTag[] = []
  // Randomly assign 1-3 tags to each project
  const allTags: ProjectTag[] = [
    "DeFi",
    "NFT",
    "Gaming",
    "Infrastructure",
    "Social",
    "DAO",
    "Privacy",
    "Scaling",
    "Identity",
    "Wallet",
    "Exchange",
    "Analytics",
  ]

  const numTags = Math.floor(Math.random() * 3) + 1
  for (let i = 0; i < numTags; i++) {
    const randomTag = allTags[Math.floor(Math.random() * allTags.length)]
    if (!tags.includes(randomTag)) {
      tags.push(randomTag)
    }
  }

  // Generate random dates within the last year
  const now = new Date()
  const oneYearAgo = new Date(now.getFullYear() - 1, now.getMonth(), now.getDate())
  const randomDate = new Date(oneYearAgo.getTime() + Math.random() * (now.getTime() - oneYearAgo.getTime()))
  const updatedDate = new Date(randomDate.getTime() + Math.random() * (now.getTime() - randomDate.getTime()))

  // Generate random number of contributors (1-8)
  const numContributors = Math.floor(Math.random() * 8) + 1
  const contributors = Array(numContributors)
    .fill(null)
    .map((_, i) => ({
      id: `contributor-${index}-${i}`,
      name: `Contributor ${i + 1}`,
      avatar: `/placeholder.svg?height=40&width=40`,
    }))

  // For the first project, use a specific name
  const name = index === 0 ? "World Liberty Financial" : `Project ${index + 1}`

  return {
    id: id, // Use the fixed ID
    name,
    description:
      "A decentralized application that enables users to interact with blockchain technology in a seamless and intuitive way.",
    owner: index === 0 ? "Kritik Namir" : `User ${Math.floor(Math.random() * 100) + 1}`,
    tags,
    stars: Math.floor(Math.random() * 1000),
    forks: Math.floor(Math.random() * 500),
    contributors,
    createdAt: randomDate.toISOString(),
    updatedAt: updatedDate.toISOString(),
    website: "https://example.com",
    twitter: "https://twitter.com/example",
    github: "https://github.com/example",
    telegram: "https://t.me/example",
  }
})

// Function to get all projects
export async function getProjects(): Promise<Project[]> {
  // No delay for better debugging
  return mockProjects
}

// Function to get project suggestions based on search query
export async function getProjectSuggestions(query: string): Promise<Project[]> {
  // Filter projects based on query
  return mockProjects
    .filter(
      (project) =>
        project.name.toLowerCase().includes(query.toLowerCase()) ||
        project.description.toLowerCase().includes(query.toLowerCase()) ||
        project.tags.some((tag) => tag.toLowerCase().includes(query.toLowerCase())),
    )
    .slice(0, 5) // Return only top 5 results
}

// Function to get a single project by ID
export async function getProjectById(id: string): Promise<Project | null> {
  console.log("Looking for project with ID:", id)
  console.log("Available project IDs:", PROJECT_IDS)

  // Always return the first project for testing purposes
  // This ensures we always get a project regardless of the ID
  return mockProjects[0]
}

