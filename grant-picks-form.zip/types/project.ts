export type ProjectTag =
  | "DeFi"
  | "NFT"
  | "Gaming"
  | "Infrastructure"
  | "Social"
  | "DAO"
  | "Privacy"
  | "Scaling"
  | "Identity"
  | "Wallet"
  | "Exchange"
  | "Analytics"

export interface ProjectContributor {
  id: string
  name: string
  avatar: string
}

export interface Project {
  id: string
  name: string
  description: string
  owner: string
  tags: ProjectTag[]
  stars: number
  forks: number
  contributors: ProjectContributor[]
  createdAt: string
  updatedAt: string
  website?: string
  twitter?: string
  github?: string
  telegram?: string
}

