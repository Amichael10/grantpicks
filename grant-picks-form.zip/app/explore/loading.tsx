export default function Loading() {
  return (
    <div className="min-h-screen bg-gray-50 font-titillium">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8">
            <div className="h-10 w-64 bg-gray-200 rounded-md animate-pulse mx-auto mb-4"></div>
            <div className="h-6 w-full max-w-2xl bg-gray-200 rounded-md animate-pulse mx-auto"></div>
          </div>

          {/* Toggle skeleton */}
          <div className="flex justify-center mb-6">
            <div className="h-10 w-64 bg-gray-200 rounded-full animate-pulse"></div>
          </div>

          {/* Filter skeleton */}
          <div className="mb-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="h-10 bg-gray-200 rounded-full animate-pulse flex-grow"></div>
              <div className="flex gap-4">
                <div className="h-10 w-40 bg-gray-200 rounded-full animate-pulse"></div>
                <div className="h-10 w-32 bg-gray-200 rounded-full animate-pulse"></div>
              </div>
            </div>
          </div>

          {/* Title skeleton */}
          <div className="mb-6 flex justify-between items-center">
            <div className="h-8 w-40 bg-gray-200 rounded-md animate-pulse"></div>
            <div className="h-6 w-20 bg-gray-200 rounded-md animate-pulse"></div>
          </div>

          {/* Cards skeleton */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
                <div className="flex justify-between items-start mb-6">
                  <div className="w-12 h-12 rounded-full bg-gray-200 animate-pulse"></div>
                  <div className="w-32 h-8 bg-gray-200 rounded-full animate-pulse"></div>
                </div>
                <div className="h-7 w-3/4 bg-gray-200 rounded-md animate-pulse mb-6"></div>
                <div className="flex justify-between items-center mb-6">
                  <div className="h-5 w-32 bg-gray-200 rounded-md animate-pulse"></div>
                  <div className="h-5 w-32 bg-gray-200 rounded-md animate-pulse"></div>
                </div>
                <div className="h-12 w-full bg-gray-200 rounded-full animate-pulse"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

