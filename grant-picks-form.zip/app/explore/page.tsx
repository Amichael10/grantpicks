"use client"

import { useState } from "react"
import { RoundCard } from "@/components/rounds/round-card"
import { RoundFilters } from "@/components/rounds/round-filters"
import { RoundCategoryToggle } from "@/components/rounds/round-category-toggle"

// Mock data for rounds
const activeRounds = [
  {
    id: "round-1",
    title: "Web3 Education & Skill Development",
    logo: "/placeholder.svg?height=48&width=48",
    isApplicationOpen: true,
    participantsCount: 8,
    closesIn: "3days",
  },
  {
    id: "round-2",
    title: "DeFi Innovation Fund",
    logo: "/placeholder.svg?height=48&width=48",
    isApplicationOpen: true,
    isParticipating: true,
    participantsCount: 12,
    closesIn: "5days",
  },
  {
    id: "round-3",
    title: "Climate Action Grants",
    logo: "/placeholder.svg?height=48&width=48",
    isApplicationOpen: true,
    participantsCount: 15,
    closesIn: "7days",
  },
  {
    id: "round-9",
    title: "NFT Creator Fund",
    logo: "/placeholder.svg?height=48&width=48",
    isApplicationOpen: true,
    participantsCount: 10,
    closesIn: "4days",
  },
]

const upcomingRounds = [
  {
    id: "round-4",
    title: "Public Goods Funding Round #5",
    logo: "/placeholder.svg?height=48&width=48",
    isApplicationOpen: false,
    participantsCount: 0,
    closesIn: "14days",
  },
  {
    id: "round-5",
    title: "Gaming & Metaverse Projects",
    logo: "/placeholder.svg?height=48&width=48",
    isApplicationOpen: false,
    participantsCount: 0,
    closesIn: "21days",
  },
  {
    id: "round-10",
    title: "Privacy & Security Solutions",
    logo: "/placeholder.svg?height=48&width=48",
    isApplicationOpen: false,
    participantsCount: 0,
    closesIn: "30days",
  },
  {
    id: "round-11",
    title: "Cross-Chain Interoperability",
    logo: "/placeholder.svg?height=48&width=48",
    isApplicationOpen: false,
    participantsCount: 0,
    closesIn: "45days",
  },
]

const pastRounds = [
  {
    id: "round-6",
    title: "Web3 Education & Skill Development",
    logo: "/placeholder.svg?height=48&width=48",
    isApplicationOpen: false,
    participantsCount: 24,
    closesIn: "0days",
  },
  {
    id: "round-7",
    title: "Infrastructure & Developer Tools",
    logo: "/placeholder.svg?height=48&width=48",
    isApplicationOpen: false,
    participantsCount: 18,
    closesIn: "0days",
  },
  {
    id: "round-8",
    title: "Community Building Initiatives",
    logo: "/placeholder.svg?height=48&width=48",
    isApplicationOpen: false,
    participantsCount: 32,
    closesIn: "0days",
  },
  {
    id: "round-12",
    title: "DAO Governance Experiments",
    logo: "/placeholder.svg?height=48&width=48",
    isApplicationOpen: false,
    participantsCount: 27,
    closesIn: "0days",
  },
]

export default function ExplorePage() {
  const [activeCategory, setActiveCategory] = useState<"active" | "upcoming" | "past">("active")

  // Determine which rounds to display based on the active category
  const displayRounds = () => {
    switch (activeCategory) {
      case "active":
        return activeRounds
      case "upcoming":
        return upcomingRounds
      case "past":
        return pastRounds
      default:
        return activeRounds
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 font-titillium">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">EXPLORE ROUNDS</h1>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Discover and participate in funding rounds for blockchain projects. Support innovation and help build the
              future of web3.
            </p>
          </div>

          <RoundCategoryToggle activeCategory={activeCategory} onChange={setActiveCategory} />

          <div className="mt-6">
            <RoundFilters />
          </div>

          {/* Removed duplicate Create Round button */}

          <div className="mb-6 flex justify-between items-center mt-6">
            <h2 className="text-2xl font-bold text-gray-900">
              {activeCategory === "active" && "Active Rounds"}
              {activeCategory === "upcoming" && "Upcoming Rounds"}
              {activeCategory === "past" && "Past Rounds"}
            </h2>
            <span className="text-gray-500">{displayRounds().length} rounds</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {displayRounds().map((round) => (
              <RoundCard
                key={round.id}
                id={round.id}
                title={round.title}
                logo={round.logo}
                isApplicationOpen={round.isApplicationOpen}
                isParticipating={round.isParticipating}
                participantsCount={round.participantsCount}
                closesIn={round.closesIn}
              />
            ))}
          </div>

          {displayRounds().length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg">No rounds found in this category.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

