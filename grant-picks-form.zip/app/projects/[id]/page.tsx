import { getProjectById } from "@/lib/projects"
import { ProjectHeader } from "@/components/projects/project-header"
import { ProjectStats } from "@/components/projects/project-stats"
import { ProjectTabs } from "@/components/projects/project-tabs"

interface ProjectPageProps {
  params: {
    id: string
  }
}

export default async function ProjectPage({ params }: ProjectPageProps) {
  console.log("Received project ID param:", params.id)

  // Get the project by ID
  const project = await getProjectById(params.id)

  // For now, we'll always show the project details even if the project is not found
  // This ensures the page renders correctly while we debug the routing issue

  return (
    <div className="min-h-screen bg-gray-50 font-titillium">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden mb-6">
            <ProjectHeader
              project={
                project || {
                  id: "project-1",
                  name: "Kritik Namir Kushna",
                  owner: "Kritik Namir",
                  description: "Project description",
                  tags: [],
                  stars: 0,
                  forks: 0,
                  contributors: [],
                  createdAt: new Date().toISOString(),
                  updatedAt: new Date().toISOString(),
                }
              }
            />
            <ProjectStats
              project={
                project || {
                  id: "project-1",
                  name: "Kritik Namir Kushna",
                  owner: "Kritik Namir",
                  description: "Project description",
                  tags: [],
                  stars: 0,
                  forks: 0,
                  contributors: [],
                  createdAt: new Date().toISOString(),
                  updatedAt: new Date().toISOString(),
                }
              }
            />
          </div>

          <ProjectTabs
            project={
              project || {
                id: "project-1",
                name: "Kritik Namir Kushna",
                owner: "Kritik Namir",
                description: "Project description",
                tags: [],
                stars: 0,
                forks: 0,
                contributors: [],
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
              }
            }
          />
        </div>
      </div>
    </div>
  )
}

