import Link from "next/link"

export default function TestPage() {
  return (
    <div className="container mx-auto p-8">
      <h1 className="text-2xl font-bold mb-4">Project Routing Test</h1>
      <div className="space-y-4">
        <div>
          <h2 className="text-xl font-semibold mb-2">Test Links</h2>
          <div className="space-y-2">
            <div>
              <Link href="/projects/project-1" className="text-blue-500 hover:underline">
                Project 1
              </Link>
            </div>
            <div>
              <Link href="/projects/project-2" className="text-blue-500 hover:underline">
                Project 2
              </Link>
            </div>
            <div>
              <Link href="/projects/project-3" className="text-blue-500 hover:underline">
                Project 3
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

