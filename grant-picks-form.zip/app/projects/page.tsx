import { ProjectCard } from "@/components/project-card"
import { Pagination } from "@/components/pagination"
import { Search } from "lucide-react"

export default function ProjectsPage() {
  // Mock data for projects
  const projects = Array(9).fill({
    id: "1",
    title: "World Liberty Financial",
    description:
      "Lorem ipsum dolor sit amet consectetur. Laoreet erat sed sit vivamus. Molestie elementum at amet lorem turpis phasellus amet. Accumsan nulla etiam.",
    totalRaised: "32.858 NEAR",
    rounds: 93,
    logo: "/project-logo.svg",
  })

  return (
    <main className="container mx-auto px-4 py-12 font-titillium">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-4xl font-bold text-center text-gray-900 mb-4">PROJECT REGISTRY</h1>
        <p className="text-center text-gray-700 mb-10 max-w-3xl mx-auto">
          Explore and manage all your blockchain projects in one place. Collaborate, innovate, and bring your
          decentralized ideas to life.
        </p>

        <div className="flex justify-between items-center mb-8">
          <div className="relative w-96">
            <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-gray-500" />
            </div>
            <input
              type="text"
              placeholder="Search Project..."
              className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-gray-200"
            />
          </div>

          <div className="flex gap-4 items-center">
            <select className="border border-gray-300 rounded-full px-4 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-gray-200">
              <option>Most Recent</option>
              <option>Most Funded</option>
              <option>Alphabetical</option>
            </select>

            <button className="bg-gray-900 text-white px-4 py-2 rounded-full hover:bg-gray-800 transition-colors flex items-center gap-2">
              <span className="text-lg">+</span>
              <span>Create Project</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
          {projects.map((project, index) => (
            <ProjectCard key={index} project={project} />
          ))}
        </div>

        <Pagination currentPage={1} totalPages={5} />
      </div>
    </main>
  )
}

