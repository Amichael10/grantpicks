import { getProjects } from "@/lib/projects"

export default async function DebugPage() {
  const projects = await getProjects()

  return (
    <div className="container mx-auto p-8">
      <h1 className="text-2xl font-bold mb-4">Project IDs Debug Page</h1>
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-semibold mb-4">Available Projects</h2>
        <ul className="space-y-2">
          {projects.map((project) => (
            <li key={project.id} className="p-2 border-b">
              <div className="font-medium">Project: {project.name}</div>
              <div className="text-sm text-gray-500">ID: {project.id}</div>
              <a
                href={`/projects/${project.id}`}
                className="text-blue-500 hover:underline"
                target="_blank"
                rel="noopener noreferrer"
              >
                Test Link
              </a>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}

