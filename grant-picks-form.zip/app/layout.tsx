import type React from "react"
import { Titillium_Web } from "next/font/google"
import "./globals.css"
import { ChevronDown } from "lucide-react"

// Load Titillium Web font with multiple weights for better typography control
const titilliumWeb = Titillium_Web({
  subsets: ["latin"],
  weight: ["200", "300", "400", "600", "700", "900"], // Include various weights for different text styles
  variable: "--font-titillium-web", // Create a CSS variable for the font
})

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`${titilliumWeb.className} font-titillium`}>
        <header className="bg-white border-b">
          <div className="container mx-auto px-4 py-4 flex justify-between items-center">
            <a href="/" className="flex items-center">
              <img
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-iK8yP4DeDH2NmcfjFsCwr0xq8Fw6q0.png"
                alt="GrantPicks"
                className="h-8"
              />
            </a>
            <div className="flex gap-6 items-center">
              <a href="/explore" className="text-gray-700 hover:text-gray-900 font-medium">
                EXPLORE
              </a>
              <a href="/projects" className="text-gray-700 hover:text-gray-900 font-medium">
                PROJECTS
              </a>
              <div className="flex items-center gap-2 bg-gray-100 rounded-full px-3 py-1.5">
                <div className="w-6 h-6 rounded-full bg-red-500 flex items-center justify-center text-white text-xs font-bold">
                  D
                </div>
                <span className="text-sm font-medium">DKRITIK.NEAR</span>
                <ChevronDown className="h-4 w-4 text-gray-500" />
              </div>
            </div>
          </div>
        </header>
        {children}
      </body>
    </html>
  )
}



import './globals.css'

export const metadata = {
      generator: 'v0.dev'
    };
